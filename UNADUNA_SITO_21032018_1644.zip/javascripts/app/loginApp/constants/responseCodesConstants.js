angular.module('loginModule').constant('RESPONSE_CODES',{
	  okResponse: 'ok',
	  koResponse: 'ko'
	}
);
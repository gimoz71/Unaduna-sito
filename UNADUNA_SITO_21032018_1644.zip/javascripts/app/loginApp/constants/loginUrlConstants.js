angular.module('loginModule').constant('URLS',{
		login: 'https://vdusszpknj.execute-api.eu-central-1.amazonaws.com/Marte5LoginStage'
		//login: 'http://localhost:2389'
	}
);
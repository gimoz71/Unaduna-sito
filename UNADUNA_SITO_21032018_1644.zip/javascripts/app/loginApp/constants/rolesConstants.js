angular.module('loginModule').constant('ROLES',{
		  all: '*',
		  admin: 'ADMIN',
		  user: 'USER'
		}
);
var app = angular.module("loginModule", []);
